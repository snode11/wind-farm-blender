"""WFRL Blender: deterministic offline presentation, explicitly SYNTH."""
from __future__ import annotations

from .cameras import build_cameras
from .scene_builder import build_scene
from .scene_model import SceneDTO
from .state import END_FRAME, apply_demo_state, demo_keyframes, sample_demo, time_for_frame
from .workspace import ensure_workspace


def _cancel_playback():
    import bpy
    if bpy.app.background:
        return
    for window in bpy.context.window_manager.windows:
        if window.screen.is_animation_playing:
            with bpy.context.temp_override(window=window, screen=window.screen):
                bpy.ops.screen.animation_cancel(restore_frame=False)


def _update_layers(scene, context=None):
    for obj in scene.objects:
        visible = None
        if obj.name.startswith("WFRL.WakeProxy."):
            visible = scene.wfrl_show_wake
        elif obj.name.startswith("WFRL.Fixture.T1.Lidar"):
            visible = scene.wfrl_show_lidar
        if visible is not None:
            obj.hide_render = not visible
            obj.hide_set(not visible)


def _update_selection(scene, context):
    import bpy
    obj = scene.objects.get(f"WFRL.Turbine.{scene.wfrl_selected_turbine}.Nacelle")
    if obj is not None and context and context.view_layer:
        for selected in context.selected_objects:
            selected.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = None
    _update_demo_status(scene)


def _update_manual(scene, context=None):
    _update_demo_status(scene)


def _update_demo_status(scene, depsgraph=None):
    """Frame-aligned telemetry and pose; lifecycle stays paused during scrubbing."""
    if not scene.objects.get("WFRL.Turbine.T1.Rotor"):
        return
    sample = sample_demo(time_for_frame(scene.frame_current))
    status = scene.get("wfrl_run_status", "READY")
    if status in {"STARTING", "RUNNING"}:
        scene["wfrl_run_status"] = str(sample.status)
        if scene.frame_current >= END_FRAME:
            import bpy
            if not bpy.app.background and not bpy.app.timers.is_registered(_cancel_playback):
                bpy.app.timers.register(_cancel_playback, first_interval=0.0)
    yaw, pitch, rpm = list(sample.yaw_deg), list(sample.pitch_deg), list(sample.rpm)
    manual = getattr(scene, "wfrl_manual_enabled", False) and scene.get("wfrl_run_status") == "PAUSED"
    if manual:
        index = ("T1", "T2", "T3").index(scene.wfrl_selected_turbine)
        yaw[index], pitch[index], rpm[index] = scene.wfrl_manual_yaw, scene.wfrl_manual_pitch, 0.0
    apply_demo_state(yaw, pitch, rpm, sample.rotor_rad)
    scene["wfrl_demo_time_s"] = sample.time_s
    scene["wfrl_demo_phase"] = "Manual pose (paused)" if manual else sample.label
    if getattr(scene, "wfrl_channel_telemetry", True):
        scene["wfrl_yaw_deg"] = yaw
        scene["wfrl_pitch_deg"] = pitch
        scene["wfrl_rpm"] = rpm
        # Manual pose is not a power model: power is unavailable in that mode.
        scene["wfrl_power_mw"] = list(sample.power_mw)
        scene["wfrl_power_available"] = not manual
        scene["wfrl_telemetry_time_s"] = sample.time_s
    scene["wfrl_fidelity"] = "SYNTH"


def _on_load(_unused):
    import bpy
    for scene in bpy.data.scenes:
        if scene.objects.get("WFRL.Turbine.T1.Rotor"):
            scene["wfrl_run_status"] = "STOPPED" if scene.frame_current >= END_FRAME else ("READY" if scene.frame_current == 1 else "PAUSED")
            _update_layers(scene)
            _update_demo_status(scene)


def _classes():
    from .panels.demo import CLASSES
    return CLASSES


def register():
    import bpy
    from bpy.app.handlers import persistent
    for cls in _classes():
        if not cls.is_registered:
            bpy.utils.register_class(cls)
    definitions = {
        "wfrl_selected_turbine": bpy.props.EnumProperty(items=(("T1", "T1", "Upstream turbine"), ("T2", "T2", "Middle turbine"), ("T3", "T3", "Downstream turbine")), default="T1", update=_update_selection),
        "wfrl_fixture_state": bpy.props.EnumProperty(items=(("NOMINAL", "Nominal", ""), ("WAITING", "Waiting", ""), ("CHANNEL_OFF", "Channel Off", ""), ("STALE", "Stale Data", ""), ("INCOMPATIBLE", "Bad Checkpoint", ""), ("FAILED", "Failed", "")), default="NOMINAL"),
        "wfrl_show_wake": bpy.props.BoolProperty(default=True, update=_update_layers),
        "wfrl_show_lidar": bpy.props.BoolProperty(default=True, update=_update_layers),
        "wfrl_channel_telemetry": bpy.props.BoolProperty(default=True, update=_update_manual),
        "wfrl_manual_enabled": bpy.props.BoolProperty(default=False, update=_update_manual),
        "wfrl_manual_yaw": bpy.props.FloatProperty(default=0, min=-30, max=30, update=_update_manual),
        "wfrl_manual_pitch": bpy.props.FloatProperty(default=2, min=0, max=90, update=_update_manual),
    }
    for name, prop in definitions.items():
        if not hasattr(bpy.types.Scene, name):
            setattr(bpy.types.Scene, name, prop)
    for handlers, function in ((bpy.app.handlers.frame_change_post, _update_demo_status), (bpy.app.handlers.load_post, _on_load)):
        persistent(function)
        if function not in handlers:
            handlers.append(function)
    # Blender installs extensions under _RestrictData; scene setup belongs to Load Demo.
    if hasattr(bpy.data, "workspaces"):
        ensure_workspace()
    from .presentation import register_overlay
    register_overlay()


def unregister():
    import bpy
    from .presentation import unregister_overlay
    unregister_overlay()
    _cancel_playback()
    if bpy.app.timers.is_registered(_cancel_playback):
        bpy.app.timers.unregister(_cancel_playback)
    for handlers, function in ((bpy.app.handlers.frame_change_post, _update_demo_status), (bpy.app.handlers.load_post, _on_load)):
        if function in handlers:
            handlers.remove(function)
    for cls in reversed(_classes()):
        if cls.is_registered:
            bpy.utils.unregister_class(cls)
    for name in ("wfrl_selected_turbine", "wfrl_fixture_state", "wfrl_show_wake", "wfrl_show_lidar", "wfrl_channel_telemetry", "wfrl_manual_enabled", "wfrl_manual_yaw", "wfrl_manual_pitch"):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)


def load_demo_scene():
    import bpy
    _cancel_playback()
    dto = SceneDTO.from_mapping({"name": "turb3_demo", "backend": "demo", "turbine": "nrel5mw", "dt": 1,
        "layout": [{"id": "T1", "x": 0.0, "y": 0.0}, {"id": "T2", "x": 504.0, "y": 31.5}, {"id": "T3", "x": 1008.0, "y": 63.0}],
        "inflow": {"speed": 8.0, "direction": 270.0}})
    collection = build_scene(dto)
    build_cameras(dto)
    scene = bpy.context.scene
    scene["wfrl_run_status"] = "READY"
    scene.wfrl_manual_enabled = False
    demo_keyframes(collection)
    _update_layers(scene)
    _update_demo_status(scene)
    from .workspace import configure_presentation
    configure_presentation()
    return collection


if __name__ == "__main__":
    register()
    load_demo_scene()
