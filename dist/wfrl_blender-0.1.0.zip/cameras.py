"""Meter-scale camera rig with explicit rotor-envelope framing."""
from __future__ import annotations


def build_cameras(scene):
    import bpy
    from mathutils import Vector

    collection = bpy.data.collections['WFRL_Scene']
    center = Vector((sum(t.x_m for t in scene.turbines) / len(scene.turbines),
                     sum(t.y_m for t in scene.turbines) / len(scene.turbines), 68))
    points = [Vector((t.x_m + x, t.y_m + y, z)) for t in scene.turbines
              for x in (-70, 70) for y in (-70, 70) for z in (0, 155)]
    cameras = {}
    def create(name, location, target, bounds=None):
        data = bpy.data.cameras.new(name + '.Data')
        camera = bpy.data.objects.new(name, data)
        collection.objects.link(camera)
        camera.location = location
        camera.rotation_euler = (Vector(target) - camera.location).to_track_quat('-Z', 'Y').to_euler()
        data.clip_start, data.clip_end = .1, 10000
        data.lens = 48
        camera['fidelity'] = 'SYNTH'
        if bounds:
            data.type = 'ORTHO'
            inverse = camera.rotation_euler.to_matrix().transposed()
            local = [inverse @ (p - Vector(target)) for p in bounds]
            aspect = bpy.context.scene.render.resolution_x / bpy.context.scene.render.resolution_y
            data.ortho_scale = 2 * max(max(abs(p.x) for p in local), max(abs(p.y) for p in local) * aspect) * 1.15
        cameras[name] = camera
        return camera
    create('WFRL.Camera.World', center + Vector((-1150, -1450, 860)), center, points)
    create('WFRL.Camera.Top', center + Vector((0, 0, 1500)), center, points)
    create('WFRL.Camera.Side', center + Vector((0, -1500, 160)), center, points)
    first = scene.turbines[0]
    t1 = Vector((first.x_m, first.y_m, 0))
    create('WFRL.Camera.T1.Closeup', t1 + Vector((-150, -205, 126)), t1 + Vector((-3, 0, 96)))
    sensor = create('WFRL.Camera.T1.Sensor', (-4, -2.4, -2.4), (-9, 0, -76))
    sensor.parent = bpy.data.objects['WFRL.Turbine.T1.YawRoot']
    sensor.data.lens = 27
    sensor['mount'] = 'nacelle_down / geometric clearance view'
    sensor.data.display_size = 1.2
    bpy.context.scene.camera = cameras['WFRL.Camera.World']
    bpy.context.scene['wfrl_camera'] = 'WFRL.Camera.World'
    bpy.context.view_layer.update()
    return cameras
