"""Idempotent procedural scene construction for the Part 2 static prototype."""

from __future__ import annotations

import math

from .materials import get_material
from .scene_model import SceneDTO


COLLECTION_NAME = "WFRL_Scene"


def _bpy():
    import bpy
    return bpy


def _link(collection, obj):
    collection.objects.link(obj)


def _finish(obj, bevel: float = 0.0, smooth: bool = False):
    """Apply small presentation modifiers without baking the mesh."""
    if smooth and hasattr(obj.data, "polygons"):
        for polygon in obj.data.polygons:
            polygon.use_smooth = True
    if bevel:
        modifier = obj.modifiers.new("WFRL.EdgeSoftening", "BEVEL")
        modifier.width = bevel
        modifier.segments = 3
        modifier.limit_method = "ANGLE"
    return obj


def _mesh_object(collection, name: str, vertices, faces, material):
    bpy = _bpy()
    mesh = bpy.data.meshes.new(name + ".Mesh")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    mesh.materials.append(material)
    _link(collection, obj)
    return obj


def _primitive(collection, kind: str, name: str, location, scale, material):
    bpy = _bpy()
    if kind == "cylinder":
        bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=1.0, depth=2.0, location=location)
    elif kind == "cone":
        bpy.ops.mesh.primitive_cone_add(vertices=32, radius1=1.0, radius2=0.78, depth=2.0, location=location)
    elif kind == "cube":
        bpy.ops.mesh.primitive_cube_add(location=location)
    elif kind == "uv_sphere":
        bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, location=location)
    else:
        raise ValueError(kind)
    obj = bpy.context.view_layer.objects.active
    obj.name = name
    obj.data.name = name + ".Mesh"
    obj.scale = scale
    obj.data.materials.append(material)
    for old in list(obj.users_collection):
        old.objects.unlink(obj)
    _link(collection, obj)
    return obj


def _rounded_nacelle_mesh(length: float, width: float, height: float):
    """Build a closed, elliptical-section nacelle shell with exact outer dimensions."""
    sections = (
        (-length * 0.5, 0.46),
        (-length * 0.43, 0.78),
        (-length * 0.31, 0.98),
        (length * 0.28, 1.00),
        (length * 0.43, 0.78),
        (length * 0.5, 0.46),
    )
    count = 32
    vertices = []
    for x, factor in sections:
        for index in range(count):
            angle = 2.0 * math.pi * index / count
            vertices.append((
                x,
                0.5 * width * factor * math.cos(angle),
                0.5 * height * factor * math.sin(angle),
            ))
    faces = []
    for section in range(len(sections) - 1):
        first, second = section * count, (section + 1) * count
        for index in range(count):
            next_index = (index + 1) % count
            faces.append((first + index, first + next_index,
                          second + next_index, second + index))
    faces.append(tuple(reversed(range(count))))
    last = (len(sections) - 1) * count
    faces.append(tuple(last + index for index in range(count)))
    return vertices, faces


def _cone(collection, name: str, radius1: float, radius2: float, depth: float, material):
    """Create a cone at the origin so its parent can own the local placement."""
    bpy = _bpy()
    bpy.ops.mesh.primitive_cone_add(
        vertices=32,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=(0, 0, 0),
    )
    obj = bpy.context.view_layer.objects.active
    obj.name = name
    obj.data.name = name + ".Mesh"
    obj.data.materials.append(material)
    for old in list(obj.users_collection):
        old.objects.unlink(obj)
    _link(collection, obj)
    return obj


def _make_blade(collection, parent, name: str, angle: float):
    from .turbine_geometry import blade_mesh, geometry_data

    bpy = _bpy()
    # ZYX gives Rx(azimuth) @ Ry(precone), followed by the blade's Rz(pitch).
    # Pitching therefore cannot collapse the three radial span directions.
    pitch_root = bpy.data.objects.new(name + ".PitchRoot", None)
    _link(collection, pitch_root)
    pitch_root.parent = parent
    pitch_root.rotation_mode = "ZYX"
    pitch_root.rotation_euler = (angle, math.radians(geometry_data()["scalars"]["PreCone(1)"]), 0.0)
    vertices, faces = blade_mesh()
    blade = _mesh_object(collection, name, vertices, faces, get_material("blade"))
    blade.parent = pitch_root
    blade.rotation_mode = "XYZ"
    _finish(blade, smooth=True)
    blade["pitch_axis"] = "LOCAL_Z"
    blade["geometry_source"] = "Packaged OpenFAST AeroDyn 19 stations / 8 measured airfoil outlines"
    root_fairing = _cone(
        collection,
        name + ".RootFairing",
        radius1=0.98,
        radius2=0.38,
        depth=4.0,
        material=get_material("hub"),
    )
    root_fairing.parent = pitch_root
    root_fairing.location = (0, 0, 3.15)
    _finish(root_fairing, bevel=0.08, smooth=True)
    root_fairing["geometry_source"] = "NREL 5MW blade-root fairing presentation detail"
    return blade


def _make_turbine(collection, turbine):
    from .turbine_geometry import geometry_data, hub_position, tower_mesh

    bpy = _bpy()
    data = geometry_data()
    scalars, shell = data["scalars"], data["shell"]
    prefix = f"WFRL.Turbine.{turbine.turbine_id}"
    root = bpy.data.objects.new(prefix, None)
    root.location = (turbine.x_m, turbine.y_m, 0.0)
    _link(collection, root)
    vertices, faces = tower_mesh()
    tower = _mesh_object(collection, prefix + ".Tower", vertices, faces, get_material("tower"))
    tower.parent = root
    _finish(tower, smooth=True)
    bearing = _primitive(
        collection,
        "cylinder",
        prefix + ".YawBearing",
        (0, 0, 0),
        (2.3, 2.3, 0.28),
        get_material("hub"),
    )
    bearing.parent = root
    bearing.location = (0, 0, scalars["TowerHt"] + 0.16)
    _finish(bearing, bevel=0.08, smooth=True)
    bearing["geometry_source"] = "NREL 5MW tower-top yaw bearing presentation detail"
    for z, radius in ((0.28, 3.06), (scalars["TowerHt"] - 0.18, 1.965)):
        collar = _primitive(collection, "cylinder", prefix + f".TowerCollar{int(z)}", (0, 0, 0), (radius, radius, 0.16), get_material("hub"))
        collar.parent = root
        collar.location = (0, 0, z)
        _finish(collar, bevel=0.04, smooth=True)
    yaw = bpy.data.objects.new(prefix + ".YawRoot", None)
    _link(collection, yaw)
    yaw.parent = root
    yaw.location = (0, 0, scalars["TowerHt"])
    hub_x, _, hub_z = hub_position()
    # Shell dimensions are explicit local YAML dimensions (8.03 x 3.30 x 3.30 m).
    # Elliptical longitudinal sections keep the source envelope while avoiding a boxy body.
    nacelle_vertices, nacelle_faces = _rounded_nacelle_mesh(
        shell["length"], shell["width"], shell["height"]
    )
    nacelle = _mesh_object(
        collection,
        prefix + ".Nacelle",
        nacelle_vertices,
        nacelle_faces,
        get_material("nacelle"),
    )
    nacelle.parent = yaw
    nacelle.location = (shell["nacelle_x_bias"] * scalars["OverHang"], 0, 0.15)
    _finish(nacelle, smooth=True)
    roof = _primitive(collection, "cube", prefix + ".NacelleRoof", (0, 0, 0), (1.2, 0.95, 0.13), get_material("hub"))
    roof.parent = yaw
    roof.location = (0.65, 0, shell["height"] / 2 + 0.16)
    _finish(roof, bevel=0.12)
    shaft = _primitive(collection, "cylinder", prefix + ".MainShaft", (0, 0, 0), (0.95, 0.95, 0.7), get_material("hub"))
    shaft.parent = yaw
    shaft.location = (hub_x + 0.7, 0, hub_z - scalars["TowerHt"] - 0.06)
    shaft.rotation_euler[1] = math.radians(90.0 - scalars["ShftTilt"])
    _finish(shaft, bevel=0.06, smooth=True)
    rotor = bpy.data.objects.new(prefix + ".Rotor", None)
    _link(collection, rotor)
    rotor.parent = yaw
    rotor.location = (hub_x, 0, hub_z - scalars["TowerHt"])
    rotor.rotation_mode = "XYZ"
    rotor.rotation_euler.y = math.radians(-scalars["ShftTilt"])
    radius = shell["spinner_radius"]
    hub = _primitive(
        collection,
        "uv_sphere",
        prefix + ".Hub",
        (0, 0, 0),
        (radius * 0.62, radius, radius * 0.95),
        get_material("hub"),
    )
    hub.parent = rotor
    hub.location = (-0.35, 0.0, 0.0)
    _finish(hub, smooth=True)
    spinner = _cone(
        collection,
        prefix + ".Spinner",
        radius1=2.15,
        radius2=0.42,
        depth=3.2,
        material=get_material("hub"),
    )
    spinner.parent = rotor
    spinner.location = (-1.45, 0.0, 0.0)
    spinner.rotation_euler[1] = math.radians(-90.0)
    _finish(spinner, bevel=0.08, smooth=True)
    spinner["geometry_source"] = "NREL 5MW rotor spinner presentation detail"
    for index in range(3):
        _make_blade(collection, rotor, prefix + f".Blade{index + 1}", math.radians(120.0 * index))
    root["wfrl_turbine_id"] = turbine.turbine_id
    root["geometry_source"] = data["source"]
    root["rotor_diameter_m"] = 2 * scalars["TipRad"]
    root["hub_height_m"] = hub_z
    return root


def _make_ground_grid(collection):
    material = get_material("grid")
    for x in range(-100, 1201, 100):
        _primitive(collection, "cube", f"WFRL.Grid.X{x}", (float(x), 30.0, 0.06), (0.22, 260.0, 0.035), material)
    for y in range(-200, 301, 100):
        _primitive(collection, "cube", f"WFRL.Grid.Y{y}", (500.0, float(y), 0.06), (700.0, 0.22, 0.035), material)


def _make_label(collection, text: str, name: str, location, size: float = 11.0):
    bpy = _bpy()
    curve = bpy.data.curves.new(name + ".Data", "FONT")
    curve.body = text
    curve.align_x = "CENTER"
    curve.align_y = "CENTER"
    curve.size = size
    curve.extrude = 0.025
    obj = bpy.data.objects.new(name, curve)
    obj.location = location
    obj.rotation_euler = (math.radians(72.0), 0.0, 0.0)
    curve.materials.append(get_material("accent"))
    _link(collection, obj)
    return obj


def _make_wake(collection, scene):
    """A soft illustrative volume; no measured field and no solid annuli."""
    from .materials import wake_volume_material
    from .turbine_geometry import hub_position, geometry_data
    bpy = _bpy()
    hub_z = hub_position()[2]
    tower_height = geometry_data()["scalars"]["TowerHt"]
    for turbine in scene.turbines:
        volume = _primitive(collection, "cube", f"WFRL.WakeProxy.{turbine.turbine_id}.Volume",
                            (turbine.x_m + 245, turbine.y_m, hub_z), (240, 100, 100), wake_volume_material())
        volume.parent = bpy.data.objects[f"WFRL.Turbine.{turbine.turbine_id}.YawRoot"]
        volume.location = (245, 0, hub_z - tower_height)
        volume["fidelity"] = "SYNTH"
        volume["provenance"] = "Illustrative expanding wake; no FLORIS solve or FAST.Farm DisXY"
        volume.display_type = "WIRE"
        for index in range(7):
            phase = 2 * math.pi * index / 7
            curve = bpy.data.curves.new(f"WFRL.WakeProxy.{turbine.turbine_id}.Line{index}.Data", 'CURVE')
            curve.dimensions = '3D'; curve.bevel_depth = .12; curve.bevel_resolution = 2
            spline = curve.splines.new('POLY'); spline.points.add(47)
            for j, point in enumerate(spline.points):
                u = j / 47; distance = 12 + 445 * u
                radius = (26 + 30 * u) * (.6 + .16 * (index % 3))
                angle = phase + .08 * math.sin(u * 7 + index)
                point.co = (distance, radius * math.cos(angle), hub_z + radius * math.sin(angle), 1)
            curve.materials.append(get_material('wake_line'))
            obj = bpy.data.objects.new(f"WFRL.WakeProxy.{turbine.turbine_id}.Line{index}", curve)
            _link(collection, obj); obj['fidelity'] = 'SYNTH'
            obj.parent = volume.parent
            obj.location = (0, 0, -tower_height)


def _make_sensor_fixtures(collection, scene):
    """Create clearly synthetic sensor rays and an exported-layer placeholder."""
    material = get_material("accent")
    turbine = scene.turbines[0]
    for index, offset in enumerate((-7.0, 0.0, 7.0), start=1):
        ray = _primitive(
            collection,
            "cube",
            f"WFRL.Fixture.T1.LidarRay{index}",
            (turbine.x_m + 72.0, turbine.y_m + offset, 88.0),
            (72.0, 0.18, 0.18),
            material,
        )
        ray["fidelity"] = "SYNTH"
        ray["provenance"] = "T1 lidar presentation fixture"
    # DisXY is intentionally a muted, hidden placeholder until a real export exists.
    for index, x in enumerate((250.0, 330.0, 410.0), start=1):
        marker = _primitive(collection, "cube", f"WFRL.Fixture.DisXY{index}", (x, 170.0, 2.0), (10.0, 10.0, 0.15), get_material("foundation"))
        marker.hide_render = True
        marker.hide_set(True)
        marker["fidelity"] = "EXPORTED"
        marker["provenance"] = "FAST.Farm DisXY placeholder; no export loaded"


def _configure_environment(collection):
    bpy = _bpy()
    from mathutils import Vector

    world = bpy.context.scene.world or bpy.data.worlds.new("WFRL.World")
    bpy.context.scene.world = world
    world.use_nodes = True
    background = next((item for item in world.node_tree.nodes if item.type == "BACKGROUND"), None)
    background.inputs["Color"].default_value = (0.022, 0.034, 0.050, 1.0)
    background.inputs["Strength"].default_value = 0.62
    for name, light_type, location, energy, color in (
        ("WFRL.Light.Key", "SUN", (-400.0, -700.0, 800.0), 2.8, (0.87, 0.94, 1.0)),
        ("WFRL.Light.Fill", "SUN", (900.0, 500.0, 420.0), 1.4, (0.58, 0.76, 1.0)),
        ("WFRL.Light.Rim", "SUN", (0.0, 0.0, 800.0), 1.4, (1.0, 0.88, 0.70)),
    ):
        data = bpy.data.lights.new(name + ".Data", light_type)
        data.energy = energy
        data.color = color
        if light_type == "SUN":
            data.angle = math.radians(18)
        if light_type == "AREA":
            data.shape = "DISK"
            data.size = 600.0
        obj = bpy.data.objects.new(name, data)
        obj.location = location
        obj.rotation_euler = (Vector((500.0, 30.0, 65.0)) - obj.location).to_track_quat("-Z", "Y").to_euler()
        _link(collection, obj)


def _configure_render():
    scene = _bpy().context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1.0
    scene.view_settings.look = "AgX - Medium High Contrast"


def clear_scene(collection_name: str = COLLECTION_NAME):
    bpy = _bpy()
    collection = bpy.data.collections.get(collection_name)
    if not collection:
        return
    for obj in list(collection.objects):
        data = obj.data
        action = obj.animation_data.action if obj.animation_data else None
        bpy.data.objects.remove(obj, do_unlink=True)
        for block in (data, action):
            if block is not None and block.users == 0 and block.name.startswith("WFRL."):
                bpy.data.batch_remove(ids=(block,))
    bpy.data.collections.remove(collection)


def build_scene(scene: SceneDTO, collection_name: str = COLLECTION_NAME):
    bpy = _bpy()
    existing = bpy.data.collections.get(collection_name)
    if existing:
        clear_scene(collection_name)
    collection = bpy.data.collections.new(collection_name)
    bpy.context.scene.collection.children.link(collection)
    collection["wfrl_scene"] = scene.name
    collection["backend"] = scene.backend
    collection["fidelity"] = "SYNTH"
    for turbine in scene.turbines:
        _make_turbine(collection, turbine)
        _primitive(collection, "cylinder", f"WFRL.Turbine.{turbine.turbine_id}.Foundation", (turbine.x_m, turbine.y_m, 0.4), (7.5, 7.5, 0.4), get_material("foundation"))
        _make_label(collection, turbine.turbine_id, f"WFRL.Label.{turbine.turbine_id}", (turbine.x_m, turbine.y_m - 18.0, 6.0))
    _primitive(collection, "cube", "WFRL.Terrain", (500.0, 30.0, -2.0), (700.0, 260.0, 2.0), get_material("terrain"))
    _make_ground_grid(collection)
    # A restrained set of arrows makes the inflow direction legible without implying a measured field.
    for index, y in enumerate((-72.0, 30.0, 132.0), start=1):
        _primitive(collection, "cube", f"WFRL.Inflow.Arrow{index}.Shaft", (60.0, y, 1.0), (38.0, 0.8, 0.8), get_material("accent"))
        arrow = _primitive(collection, "cone", f"WFRL.Inflow.Arrow{index}.Head", (102.0, y, 1.0), (4.0, 3.2, 2.2), get_material("accent"))
        arrow.rotation_euler[1] = math.radians(90.0)
    _make_wake(collection, scene)
    _make_sensor_fixtures(collection, scene)
    _configure_environment(collection)
    _configure_render()
    return collection
