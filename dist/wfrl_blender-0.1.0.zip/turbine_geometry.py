"""NREL 5MW design meshes, using only the packaged asset and Python stdlib.

The loft follows wfrl/viz/geometry.py: reference-point aligned airfoil sections,
structural twist, and interpolation of the 19 AeroDyn stations. Local blade
coordinates are x axial/downstream, y chordwise, z radial. No backend imports.
"""
from __future__ import annotations

from bisect import bisect_right
from functools import lru_cache
import json
import math
from pathlib import Path


@lru_cache(maxsize=1)
def geometry_data():
    return json.loads((Path(__file__).parent / "assets/nrel5mw_geometry.json").read_text())


def hub_position():
    """Hub relative to tower ground origin, before nacelle yaw, in metres."""
    scalars = geometry_data()["scalars"]
    tilt = math.radians(-scalars["ShftTilt"])
    return (scalars["OverHang"] * math.cos(tilt), 0.0,
            scalars["TowerHt"] - scalars["OverHang"] * math.sin(tilt))


def _resample_ring(points, count):
    # Close the outline, then sample without repeating the seam vertex.
    points = [tuple(p) for p in points]
    if math.dist(points[0], points[-1]) > 1e-10:
        points.append(points[0])
    distances = [0.0]
    for a, b in zip(points, points[1:]):
        distances.append(distances[-1] + math.dist(a, b))
    output = []
    for i in range(count):
        target = distances[-1] * i / count
        j = min(bisect_right(distances, target) - 1, len(points) - 2)
        fraction = (target - distances[j]) / (distances[j + 1] - distances[j])
        output.append(tuple(a + (b - a) * fraction for a, b in zip(points[j], points[j + 1])))
    return output


def _ring_faces(rings, count):
    faces = []
    for ring in range(rings - 1):
        a, b = ring * count, (ring + 1) * count
        for j in range(count):
            k = (j + 1) % count
            faces.append((a + j, a + k, b + k, b + j))
    faces.extend((tuple(reversed(range(count))), tuple(range((rings - 1) * count, rings * count))))
    return faces


@lru_cache(maxsize=4)
def blade_mesh(subdiv=4, ring_points=96):
    """Return vertices/faces: 73 interpolated rings with curved airfoil contours."""
    if subdiv < 1 or ring_points < 12:
        raise ValueError("Blade loft needs positive subdivision and at least 12 outline points")
    data = geometry_data()
    sections = []
    for span, curve, sweep, _, twist, chord, afid in data["blade_stations"]:
        airfoil = data["airfoils"][int(afid) - 1]
        ref = airfoil["reference"]
        beta = math.radians(twist)
        ring = []
        for x, y in _resample_ring(airfoil["coordinates"], ring_points):
            u, v = (x - ref[0]) * chord, (y - ref[1]) * chord
            tangent = u * math.cos(beta) + v * math.sin(beta)
            axial = -u * math.sin(beta) + v * math.cos(beta)
            ring.append((curve + axial, sweep + tangent, data["scalars"]["HubRad"] + span))
        sections.append(ring)
    vertices = []
    for i in range(len(sections) - 1):
        for j in range(subdiv + (i == len(sections) - 2)):
            t = j / subdiv
            vertices.extend(tuple(a + (b - a) * t for a, b in zip(p, q))
                            for p, q in zip(sections[i], sections[i + 1]))
    # Swapping airfoil (chord, thickness) into (axial, tangent) reverses winding.
    faces = _ring_faces(len(vertices) // ring_points, ring_points)
    return vertices, [tuple(reversed(face)) for face in faces]


def tower_mesh(ring_points=64):
    stations = geometry_data()["tower_stations"]
    vertices = [(diameter * 0.5 * math.cos(2 * math.pi * i / ring_points),
                 diameter * 0.5 * math.sin(2 * math.pi * i / ring_points), elevation)
                for elevation, diameter in stations for i in range(ring_points)]
    return vertices, _ring_faces(len(stations), ring_points)
