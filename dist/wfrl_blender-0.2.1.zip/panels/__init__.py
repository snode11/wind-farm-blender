"""WFRL Blender panels."""
