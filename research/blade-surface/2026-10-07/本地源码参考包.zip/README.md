# 网页 GPT 叶片三维重建交接

更新日期：2026-10-07（Asia/Shanghai）。目录名保留首次建立日期。项目仓库统一使用 [snode11/wind-farm-blender](https://github.com/snode11/wind-farm-blender)，对应本地 remote `blender-sync`。

本轮按当前本地目录和 GitHub main 元数据更新讨论材料，并加入已保留的三轮表面实验报告与判定。GitHub main 仍缺少本地 `blade_recon/`、`wfrl/nrel_reconstruction/` 和表面研究交接目录；具体身份见 [github_alignment.json](github_alignment.json)。当前 main 的版本字段为 0.3.13；安装 ZIP、当前工作区和冻结实验分别解释。

## 上传与阅读顺序

| 文件 | 用途 |
| --- | --- |
| [00_发给网页版GPT的提问.md](00_发给网页版GPT的提问.md) | 粘贴到网页对话的任务说明 |
| [01_项目背景与GitHub本地差异.md](01_项目背景与GitHub本地差异.md) | 目标、现有实现、正确仓库及其缺项 |
| [03_实验进展与下一轮讨论依据.md](03_实验进展与下一轮讨论依据.md) | 三轮实验状态、失败门槛与下一轮需要回答的问题 |
| [02_本地关键源码.md](02_本地关键源码.md) | 当前本地核心源码，附原路径、行号和 SHA-256 |
| [本地源码参考包.zip](本地源码参考包.zip) | 上述文档、选定源码及三轮报告／协议／判定 |
| [snapshot_manifest.json](snapshot_manifest.json) | 本地文件来源、字节身份及本轮 GitHub 核对身份 |
| [packaging_check.json](packaging_check.json) | ZIP 和逐文件字节一致性检查 |

先上传 01 和 03，再粘贴 00。讨论涉及实现细节时补充 02 或 ZIP；网页模型若不能读取 ZIP，则单独提供它明确需要的源文件或报告。

ZIP 内选定源码和正式证据位于 `sources/<项目相对路径>`；例如最新报告为 `sources/outputs/blade-surface-20261006-exec-a01/REPORT.md`。主文档中的相对链接用于本地导航，网页模型读取附件时按此布局定位报告。

## 当前结论

表面外观、固定材料绑定和窗口联合求解已有实际实现；最新独立 run 的 P2b 为 `FAILED_GATE / REVIEW_ONLY`，主增益为 `null`。自动长身份延续失败，32 帧联合几何数值结论不确定；局部观测门槛失败，局部恢复 `NOT_RUN`、深度 `null`。软件和外观展示通过的范围见正式报告，不构成现场精度或健康监测验收。

小包不包含真实 RGB 序列、视频、大数组、模型权重、虚拟环境或 Blender 场景。当前本地仍保留核心实验输入和结果；需要图像证据时按正式 run 路径选取。历史完整归档上传记录由[原发布回执](../cleanup-blade-surface-local-20261006/publication-receipt.json)解释，不作为项目仓库入口；本轮项目仓库中未找到相应实验 tag 或 Release。

本轮修改范围为本地文档、讨论源码快照和小型附件包。原正式报告、协议、判定及历史上传回执保持原文；完整旧交接包和本轮修改前的文件保存在 [before 备份目录](../document-alignment-20261007/before/)。
