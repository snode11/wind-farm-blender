# NREL 叶片缺陷编辑器

更新日期：2026-10-06。当前扩展为 NREL / WFRL 0.3.16，要求 Blender 5.2+。

该编辑器把 GW184 的六类合成缺陷操作接入 NREL 5MW / MAPPO 柔性回放。先打开主前端的 **MAPPO · 60 秒**，在 **MAPPO** 侧栏的 **NREL 5MW · 叶片缺陷** 面板点击 **启动缺陷编辑器**；目标可以选择 T1、T2、T3 的任一叶片。缺陷尺寸、位置与形态是用户定义的合成参数，不代表现场实测损伤。

该功能已随 [0.3.16 Release](https://github.com/snode11/wind-farm-blender/releases/tag/v0.3.16) 的扩展 ZIP 发布，安装后重启 Blender 即可使用；本次未更新本机日常安装。macOS 也可以双击[打开 NREL 缺陷编辑器](../../scripts/blender/打开NREL缺陷编辑器.command)，直接打开使用工作区源码的独立 Blender 窗口。从仓库根目录也可运行以下命令，复用内置 MAPPO 结果：

```sh
blender --factory-startup --python scripts/blender/open_nrel_defect_editor.py
```

[命令行入口](../../scripts/blender/nrel_defects.py)还提供 `edit`、`prepare`、`analyze`、`scan`、`images` 模式；证据模式要求明确的输出目录，`images` 按显式请求采集图片。启动与编辑不会运行求解器。

支持材质细裂纹、几何开口裂缝、凹坑、局部表面侵蚀、涂层剥落和雷击损伤。细裂纹与涂层剥落只有材质外观；开口裂缝、凹坑和侵蚀改变显示网格；雷击损伤组合烧蚀区域与凹坑，不模拟放电或内部损伤。

操作流程：

1. 选择类型并新建，设置风机、叶片、吸力面或压力面、展向位置、弦向位置、方向、长度、宽度及对应深度。也可点击目标叶片的健康参考表面定位。
2. 用预览检查候选状态，确认后生效；取消恢复完整提交状态。编辑期间冻结回放时刻，结束编辑后恢复之前的时间与播放状态。
3. 已有缺陷可以修改、启用或禁用、删除、复制为禁用实例，并支持撤销和重做。健康对照关闭目标叶片的全部缺陷，不改写提交配置。
4. 保存 JSON 配置用于后续加载；保存 `.blend` 后重开时恢复 MAPPO 与缺陷状态。配置绑定 NREL 健康参考几何及参数化身份，不直接接受 GW184 配置，也不自动把旧位置按叶长缩放。

缺陷显示网格、辅助轮廓与几何可见性支持区域使用同一份保存的柔性变换。时间跳转和反向寻址更新显示姿态，不重新执行 Boolean，也不修改 FAST.Farm / BeamDyn 的保存结果、材料刚度或净空测量。

G 分析和扫描报告理想针孔相机下的投影与几何遮挡；`VISIBLE`、候选最佳帧、投影宽度或可见面积不证明图片中可辨识。扫描区间仅覆盖实际评估的离散时刻。材质外观仍需独立审核，保存配置与 G 分析不会自动渲染图片。

当前表面域排除根部过渡、示意叶尖和跨前后缘路径；缺失数据不能靠插值生成测量。编辑器不构成结构损伤、修复效果、硬件相机同步或现场检测性能的证据。

宿主机回归见 `blender_frontend/tests/test_nrel_defects.py` 和 `test_nrel_defect_visibility.py`；原生后台回归见 `blender_frontend/tests/blender/nrel_defect_editor_regression.py`，分保存与新进程重开两个阶段。窗口操作与扫描生命周期由 `nrel_defect_window_regression.py` 独立检查。实际结果和现有基线问题见[移植验证记录](validation/NREL缺陷编辑器移植验证.md)，正式 ZIP 检查见 [0.3.16 发布核对](releases/0.3.16发布核对.md)；各层通过不能代替材质辨识或物理精度验收。
